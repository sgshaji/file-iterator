---
name: pd-ad-conversion
description: |
  Converts a source Position Description into a completed PD template document, and a completed AD template document when an AD template is supplied, then saves them to SharePoint and verifies stored byte counts before reporting success. Use when the user asks to "convert a PD", "fill the PD template", "fill PD and AD templates", "create completed PD/AD documents", or "save the converted PD to SharePoint". Do NOT use for general Word editing, generic PDF extraction, or one-off document Q&A - use docx, pdf, or document search instead.
cowork:
  category: automation
  icon: DocumentBulletList
---

# PD/AD Conversion Skill

Convert one source Position Description into the corporate Word template and store it in
SharePoint with byte-level proof. An AD template is converted too when one is supplied.

**Every package edit happens in `scripts/pd_tools.py`, never by reasoning in the chat.** You never
author, retype or carry document bytes - the upload passes a **file path**, so nothing larger than
a filename crosses into a tool call.

## Deployment bindings

The only environment-specific values in this file. Change them here when adopting this skill.

| Binding | Value |
|---|---|
| Writable directory the upload connector can read | `/app/created/` |
| Upload tool | `create_file` - params `dataset`, `folderPath`, `name`, `body`, `overwrite` |
| OCR | `rapidocr`, preinstalled - no pip, apt, or external service |
| Normal upload size overhead | up to 2,048 bytes (see section 9) |
| What decides *when* to run | a Power Automate flow, outside this skill |

## Inputs

Two required: **the template(s)** and **the source PD path**. **The destination is not an input;
it is derived (section 2).** Never ask where to save output.

The template input takes either shape:

| Given | What it means |
|---|---|
| a path to one `.docx` | that single template |
| a path to a **folder** | **every** `.docx` in it, each producing its own output |

A template folder is the normal case. Do not ask which template to use and do not pick one - a
folder means all of them.

When a flow invokes you it also supplies `siteUrl`, and the paths it gives are already resolved
server-relative paths - pass them straight to `destination` without re-resolving.

## The run, in order

The filled document **replaces the source** in the position folder under the name the source
had; what it displaced moves to `Archive/` with a timestamp. Output is always `.docx`. Every
other template writes to its own subfolder, so nothing competes for the in-place slot:

```
Positions/Medical/Divisional Director Continuing Care/
  Role.docx                                  the current PD
  Archive/
    Role_20260820-093958.pdf                 what it replaced
  AD Documents/
    Role - AD.docx                           the AD built from the same source
    Archive/
      Role - AD_20260315-101122.docx         a superseded AD
```

Sources sit at the top level and everything this skill writes goes in a subfolder, so a source is
told from output by its path alone.


1. classify each template (1a) - exactly one may be the PD template
2. confirm the source you were given is the one to convert (1b)
3. derive the destination and the archive stamp (2)
4. stage the template and the source, byte-faithfully (3)
5. inspect the template; read its `outline` (4)
6. read the source (5) and build the field map (6)
7. decide what the template says to remove (6a)
8. **fill** (7), then **prune** the filled document (6a)
9. copy what is displaced into `Archive/` (7a)
10. upload (8), verify (9), delete the displaced originals (7a)
11. assemble the report (10)

`pd_tools.py` does everything that touches bytes:

| Command | Run it | Returns |
|---|---|---|
| `sources` | before converting, over the folder listing | which file of a group to convert |
| `destination` | once per template | where to write, where history goes, the shared `stamp` |
| `inspect` | once per template | fields, variants, and the paragraph `outline` |
| `variants` | when a template offers alternatives | how many, and what each applies to |
| `fill` | once per template | the filled document, and `upload_path` |
| `prune` | after `fill` | the document with instruction blocks and highlighting gone |
| `archive-name` | per displaced file | its stamped archive name |
| `verify` | after upload | that the package still opens, and its byte count |
| `report` | last | the one JSON object you reply with |

Paths are relative to the skill folder, so run them from there. Every one prints a single JSON
object and takes `--help`; read that rather than guessing a flag.

## Scope

**One source PD per invocation.** Do not scan folders, discover work, decide what to convert next,
or process a library in bulk - that is the flow's job. Asked to convert several, convert the one
you were given and say each is a separate invocation.

**Use this skill when** a PD and a template are supplied and finished documents are wanted in
SharePoint with byte verification.

**Do not use it for** generic Word creation (`docx`), PDF extraction or summarising (`pdf`),
answering questions about a PD without producing documents (document search), or editing unrelated
files.

---

## 1. Input gate

Confirm the two required inputs. Resolve SharePoint links with the SharePoint tools - never guess
drive IDs, item IDs or paths.

## 1a. Classify each template

When the template input is a folder, list it and decide for **each** `.docx` which kind it is. The
kinds are placed differently, so this decision drives section 2.

| Kind | Where its output goes |
|---|---|
| **PD template** - the position description itself | the position folder, replacing the current document |
| **AD template** - the advertisement written from it | the `AD Documents/` subfolder |

Judge it from the evidence available - the filename, and if that is not conclusive, what `inspect`
reports about the template fields. There is no fixed naming rule to apply and none should be
invented: a name that reads as an advertisement in one library will not in the next.

State your classification in the report, so a wrong call is visible rather than silent.

**Exactly one template may be the PD template** - it is the only one that replaces the live
document. If two look like the position description, **stop and report it** rather than choosing.

**If a single template is ambiguous, treat it as an AD template.** A wrong AD call leaves a stray
file in a subfolder; a wrong PD call overwrites the position's current document. Prefer the
recoverable error.

Ignore anything in the folder that is not a `.docx`, and ignore Word lock files (`~$...`).

## 1b. Confirm the source is the one to convert

A position folder holds more than one document, and often holds the **same** document twice - once
scanned as `.pdf` and once as `.docx`. Only one of a pair may be converted, or two conversions
compete for the same output name.

List the position folder and run:

```bash
python scripts/pd_tools.py sources --files listing.json
```

Each entry needs a name, a folder path and a modified time - pass the listing through as the
SharePoint tools returned it.

Find the group whose `convert` is the source you were given.

- **It is the `convert` file** -> proceed. Keep its `displaced` list; section 7a archives all of them.
- **It is in a group `displaced` list but is not the `convert` file** -> another format of the same
  document is the one to convert. **Stop, and report it as skipped with that reason.** This is a
  normal outcome, not a failure.
- **It is not in any group** -> `sources` did not consider it convertible. Report why.

The choice within a pair prefers the PDF, which is usually the signed version - unless the Word
file was modified later, in which case someone has revised it and that revision is the current
statement of the role. `sources` reports `why`; repeat it in the run report.

## 2. Derive the destination

The destination is never an input. Run `destination` once per template - add `--output ad` for an
AD template.

```bash
python scripts/pd_tools.py destination \
  --source   "<resolved server-relative path of the source document>" \
  --modified "<lastModifiedDateTime of that source>"
```

It returns where to write, where history goes, and one `stamp` covering everything this conversion
displaces. Its `next` field says what to do with them.

Pass a **resolved** path, never a sharing link. On any `ERROR` the `action` field says what to fix:
do that rather than working around it, and never shorten a path to fit.

Create `destination_folder_path` if it is missing, using the name exactly. If it already exists,
reuse it - a create-folder tool that returns `... (1)` has made a duplicate.

## 3. Stage the files - byte-faithful reads only

Download the PD template, the AD template if supplied, and the source PD. Nothing else in this
skill reads from SharePoint.

**Pick whichever read tool you actually have** that satisfies all three: returns raw bytes or
base64 rather than text; does not decode or transcode; lets you compare against the size the
metadata reported. Tools differ between harnesses - do not stop because a particular one is absent.

> **Never let a binary be text-decoded.** A tool that infers a text content type returns the bytes
> peppered with U+FFFD replacement characters and **raises no error** - the file still starts with
> `PK` and looks plausible.

**Compare each staged file's byte count against the reported `size`.** That mismatch is the only
signal you get. If they differ, switch read method and re-stage; everything downstream is worthless
otherwise. If a source exceeds your read tool's limit, stop and report.

## 4. Inspect each template, separately

```bash
python scripts/pd_tools.py inspect --docx pd_template.docx
```

| `inspect` reports | Means | Key the map on |
|---|---|---|
| `field_names` | content controls, or `{{tokens}}` | those names |
| `anchored_fields` | plain blanks, named by the label beside or above them | those labels |
| `variants` | the document holds alternative versions | see section 4a - **all** get filled |

`anchored_detail` shows each field beside the blank it matched, so you can confirm the reading
before filling anything.

`inspect` also returns an **`outline`**: every paragraph in the document with its style, whether it
is a heading, whether it is highlighted, and whether it holds a blank. Read it. It is how you find
the things a template says about itself - see section 6a.

**Never assume a field list.** Never hardcode one, and never carry one over from a previous
conversion.

No fields of any kind? Re-run once with `--placeholder '<regex>'` describing what that template's
blanks look like. Still nothing - report and stop.

## 4a. Templates offering alternatives - fill every one

Some templates hold the same blanks more than once, one copy per variant of the role.

**Fill them all. Never choose one, never delete the others.** Choosing means asking, which does not
scale; and which variant applies is the organisation's HR judgement, not ours. Leave the template's
instruction page in place - it tells the reviewer how to choose.

```bash
python scripts/pd_tools.py variants --docx pd_template.docx
```

Reporting only - use it to state how many alternatives exist and what each `applies_to`. `inspect`
names the second copy of a blank `Position Title#2`; your map needs every name it reports, usually
with the same value in both.

## 5. Read the source PD

Extract text directly if it is Word or a text-layer PDF. If scanned or image-only, OCR it.

## 6. Build the field map

**Derive every key from *this run's* `inspect` output** - never from memory, an example, or a
previous map.

Keys are not a fixed vocabulary and not tidy identifiers: an anchored field is named by the label
read out of the document, so a key may contain spaces, punctuation or a trailing colon. **Copy each
key byte for byte**, including any `#2` suffix. Do not tidy, abbreviate, camel-case or reorder.

A heading you expected and cannot find means the template changed, which is normal. Never re-create
it and never carry a key forward from a previous version.

A flat JSON object, one key per reported field:

```json
{
  "<a name inspect returned>": "text for that field",
  "<another name inspect returned>": "line one\nline two",
  "<a name inspect returned>#2": "same answer, second variant",
  "<a field the source cannot answer>": null,
  "@41": "text for outline row 41"
}
```

`null` means the document does not answer that field - see below.

**`@41` addresses outline row 41 directly**, by the `index` each row carries. Discovery names a
blank from the text above it, which handles most templates and not all; when the outline plainly
shows a blank that was never named, fill it by number rather than reporting it as unfillable.
Prefer a discovered name where there is one - it survives the template being re-ordered, and a row
number does not.

### Quote, do not rewrite

A converted PD is an HR and legal document. Copy the source's wording verbatim - its spelling,
tense and voice. Trim and re-punctuate to fit the field; nothing more.

No paraphrase, no summary, no synonyms, no re-voicing, no reordering for style, no improving the
prose, no localising the spelling. If you cannot use the source's own words, the field is not
answerable from the source.

All three of these were produced by earlier runs:

| Source says | Wrong | Why |
|---|---|---|
| working closely with the leadership team | I would work closely with... | first person and conditional; a PD is not in the holder's voice |
| Identify opportunities to improve efficiency | Spot opportunities to boost efficiency | synonyms; two runs then disagree on the same PD |
| maximising business performance | maximizing business performance | silently localised an Australian document |

### Fill a heading only from content that belongs under it

Never move content from one part of the source into a differently-named template heading because
that heading would otherwise be empty. **An empty field is a correct answer; a plausibly-filled
wrong field is undetectable downstream.**

- Match on what the content **is**, not on whether it is topically adjacent.
- **About to write "(categorisation under this heading inferred)" or similar? Stop.** That phrase
  means the content does not belong under that heading - set the field to `null` instead. Such
  caveats also ship to the customer inside their document.
- `(inferred; ...)` is for a value you *read elsewhere in the document*. It never licenses moving
  content under a heading it does not belong to.
- A new template legitimately asks for things older PDs never recorded. Unfilled fields are an
  expected outcome, not a problem to solve by finding something to put there.

Applied identically every run, because at thousands of PDs run-to-run variance is itself a defect.

### When the template asks something the field does not answer

A blank field does not mean the document is silent. The answer is often written somewhere else in
it - a reporting line named in the role statement, a division in the header, a title on the front
page. Three outcomes, and which applies depends on **where the answer could come from**.

**The document answers it elsewhere - use it, and say where from.**

Write the value followed by `(inferred; <where you read it>)`:

```
Chief Operating Officer (inferred; named in the General Role Statement, not in the Reports To field)
```

This is reading, not guessing. The evidence is in the document you were given and a reviewer can
check it in seconds. Quote the wording you found, exactly as section 6 requires.

**Nothing in the document answers it - leave the blank visible.**

Set that field to `null` in the map. `fill` leaves the template's own placeholder text exactly as
written and highlights it, so the finished document shows a reviewer where to type, in the
template's own words. **Never write "Not provided", "TBC" or "N/A" into a document** - that is our
vocabulary shipped inside the customer's position description.

Every `null` field is reported in `missingFields`, so the document shows the gap and the report
counts it.

**Never infer these, however plausible the answer looks:**

classification, grade, award or agreement, salary band, employment type, approvals, delegations,
and dates.

Each of those has an authority outside the document - an award, an HR system, a signed instrument.
A value that looks right and is wrong is worse than a blank, because nobody re-checks a field that
is already filled in.

Rough OCR or truncated text is not evidence. If you cannot read it, it does not answer the field.

### Lists: one item per line

Separate items with a newline (`\n`) and nothing else. **Do not add your own `-`, `*` or `1.`
prefixes**, and do not run items together into one sentence.

`fill` turns each line into a proper Word bullet inheriting the template's own style. Your own
bullet characters produce doubled markers; run-together items produce one enormous bullet.

Prose fields are unaffected - a newline stays a line break in the same paragraph, which is correct
there.

## 6a. Do what the template tells you to do

**This runs after section 7**, on the filled document - `prune` takes `pd_filled.docx`, which
`fill` produces. Decide here what should go; remove it once the blanks are filled.

A template is not only blanks. It also carries instructions to whoever fills it in, and sections
meant to go. Filling the blanks and stopping leaves a half-finished document. Read the `outline`
from section 4 and decide what belongs in the finished document.

Three kinds of thing, handled differently:

**Remove always - no judgement involved**

- Instruction blocks addressed to the person filling the template: "Notes for the author",
  "Complete this section in consultation with HR", "Delete this page before issuing".
- Highlighting that marked a blank. Yellow shows where to type; it has no place in an issued
  position description.

**Remove when the template says so and the source decides it**

A template that says *"delete this section if the role has no direct reports"* is asking a question
the source PD answers. Read the instruction, check the source, act on it, and record what you did.

If the source does not settle it, **keep the section** and say so. Keeping something unnecessary is
visible and costs a reviewer seconds; removing something needed is invisible.

**Never remove - leave for the reviewer**

Alternative versions of the role where the source does not indicate which applies. Fill every copy
and leave the template's own instruction page explaining how to choose (section 4a). That choice is
the organisation's, not yours.

### How to remove

Name each block by its exact text. Nothing is removed by inference.

```bash
python scripts/pd_tools.py prune --docx pd_filled.docx --out pd_final.docx \
  --remove remove.json --strip-all-highlight
```

```json
{"remove": [
  {"match": "Notes for the author", "scope": "block", "until": "Position Title",
   "why": "template instruction block, addressed to whoever fills the template"},
  {"match": "Direct Reports", "scope": "block", "until": "Key Result Areas",
   "why": "template says delete if the role has none; the source PD lists none"}
]}
```

| `scope` | Removes |
|---|---|
| `paragraph` | just that paragraph |
| `table` | the whole table the match sits in - use for instruction boxes |
| `block` | that paragraph up to `until` |

**Always pass `until` on a `block` removal**, naming the first paragraph you want to keep. `prune`
refuses a block it cannot bound at all, but it cannot refuse one it bounds in the *wrong* place -
and that failure returns `status: OK`. Heading styles are not a reliable boundary: a template marks
its sections with whatever style it likes, and spacer paragraphs carry styles too.

Then read `last` and `stopped_before` in the result - the final paragraph deleted, and the first
line kept. If `last` is a heading, or `stopped_before` is not where you expected to resume, the
boundary was wrong. Re-run with a corrected `until`; the input document is untouched.

`--out` is required and must differ from `--docx`. `--heading-style` overrides what counts as a
boundary.

**Always pass `--strip-all-highlight`.** `fill` clears highlighting only from the blanks it filled;
this clears the rest. Highlighting marks where to type and has no place in an issued document, so
there is no case for leaving some behind.

A `match` that finds nothing, finds more than one paragraph, or cannot be bounded is reported in
`not_found`, `ambiguous` or `unbounded` and skipped - never guessed at. Any of the three makes the
whole call return `ERROR`.

**Every `why` is published in the run report.** If you cannot state plainly why something went,
that is the signal to keep it.

## 7. Fill and measure

Write output into the writable directory named in **Deployment bindings** - not a scratch
directory. section 8 explains why.

```bash
python scripts/pd_tools.py fill --docx pd_template.docx --map pd_map.json --out "/app/created/pd_filled.docx"
```

The helper edits the package in place, preserves every zip entry, converts newlines to `<w:br/>`,
strips highlighting from filled placeholders only, and returns byte counts and package validity.

**`fields_unmatched` must be empty.** Usually it means the map used a name the template does not
have - fix the map, do not proceed. First check `parts_not_scanned`: only `document.xml`, headers
and footers are filled, so a name `inspect` reported may sit in an unfilled part. If so the map is
right, the field cannot be filled by this helper - leave it out and record it as unfilled with the
reason.

## 7a. Archive what this conversion displaces

**Nothing is ever overwritten in place, and the live document is never absent.** For a PD the new
document takes the source name, so the order below matters more than the mechanism: **copy first,
upload second, delete last.**

What gets displaced depends on the template kind:

| Kind | Displaced |
|---|---|
| PD | the source document **and every other format of it** - the whole `displaced` list from section 1b |
| AD | the previous AD of the same name, if one exists. The source is untouched |

Name each one with the `stamp` that `destination` returned - one stamp for the whole group, not one
per file, or the group cannot be reunited later:

```bash
python scripts/pd_tools.py archive-name \
  --file  "<name of the file being displaced>" \
  --stamp "<the stamp destination returned>"
```

Then, in this order:

1. **Copy** every displaced file into `archive_folder_path` under its `archive_filename`. Copy,
   not move - the originals stay where they are.
2. Upload the new document (section 8), overwriting the one that shares its name.
3. Verify it (section 9).
4. **Only once it verifies**, delete any displaced original the upload did not overwrite - the
   other format of a pair, for instance.

Moving the source out first would leave the position folder with no current document, and if the
upload then failed the next run would find nothing to convert. Copying first means a failure costs
a stray file in `Archive/`, which is visible and harmless, instead of a position with no PD.

**Prefer the cheapest mechanism you have:**

| # | Mechanism | Bytes through you? |
|---|---|---|
| 1 | server-side **copy** | No |
| 2 | read and re-upload into `Archive/` per section 8 | **Yes** |

1 is strongly preferred. 2 works but moves bytes through the harness - say so if you use it. This
skill does not name the tool; pick whichever your tool set supports.

**If you can do neither, do not upload.** The new document would take the source name and destroy
it. Stop, and report `no-archive-mechanism`.

**If you archived but the upload never verified**, say so with `archived-not-uploaded`, naming the
archive copies you made. The originals are still in place, so the position is intact and the next
run will convert it again - but nobody should have to discover that by reading the folder.

## 8. Transport - the upload takes a **path**, not bytes

Pass the **bare absolute path** of the filled document as `body` - `fill` prints it as
`upload_path`. The connector opens that path and uploads the real file; the bytes never pass
through you.

```
create_file
  dataset:    <site URL>
  folderPath: <destination folder from section 2>
  name:       <output filename>
  body:       /app/created/pd_filled.docx   <- exactly as `fill` printed upload_path
  overwrite:  true
```

**Failure signature - memorise it.** If the stored size equals the **number of characters in the
path you sent**, the connector did not open the file; it stored your path as the contents. **It
returns Success.** Fix: write to the directory named in Deployment bindings and re-send once.

A create-folder tool returning a name with ` 1` appended means the folder already existed and it
made a duplicate - delete it and upload into the original.

**Never** recompress, re-zip, rebuild or strip the document to fit a limit, and never split a
payload or reassemble one from pieces. Size is not a reason to change the bytes.

Valid parameters and no others: `dataset`, `folderPath`, `name`, `body`, `overwrite`.

## 9. Verify

Read the stored `size` back from SharePoint. Pass it, and the bytes you sent, to `report`
(section 10) - it applies the verdict: stored below sent is truncation, stored equal to the length
of the path you sent means the connector never opened the file, and a small excess is normal
ingestion overhead.

```bash
python scripts/pd_tools.py verify --file pd_filled.docx --expect-bytes <size SharePoint reports>
```

`verify` and `report` are not the same check. `verify` re-opens the document and confirms the
package is still valid; `report` judges the byte counts. Run both.

**A `200` or `201` is not evidence.** Never present a local file or a download link as a successful
upload.

Never re-send the same bytes after they verified wrong - a stored size that is short or equal to
the path length means the transport is broken, and repeating it just breaks it again. A call that
errored before anything landed is a different case: the section 8 directory fix applies, once.

## 10. Output

Your reply is one JSON object and nothing else - no prose before or after, no code fence. A
workflow parses it; anything else is recorded as a failed conversion.

Assemble it rather than writing it out by hand:

```bash
python scripts/pd_tools.py report --run run.json
```

`run.json` is what happened, one entry per template:

```json
{
  "sourceFile": "Role.pdf",
  "sourceChosenBecause": "PDF preferred when neither is newer",
  "outputs": [
    {"template": "HR - Position Description Template.docx", "kind": "pd",
     "destinationFolderPath": "/sites/<site>/.../Medical/<position>",
     "outputFileName": "Role.docx",
     "bytesSent": 56104, "bytesStored": 56340, "uploadPathChars": 31,
     "missingFields": ["Award Classification"],
     "removed": [{"match": "Notes for the author", "scope": "block", "paragraphs": 3,
                  "why": "template instruction block"}],
     "highlightCleared": 7,
     "archivedAs": ["Role_20260820-093958.pdf", "Role_20260820-093958.docx"]}
  ],
  "notes": ""
}
```

`report` judges every upload from its own byte counts, fills in the arrays you left out, and sets
`status` to `OK` only when all of them passed. **Print exactly what it returns.**

Report every template, including ones that failed - a shorter array reads as a smaller job rather
than a broken one. `removed` carries every deletion with its reason; a removal nobody can see is a
removal nobody can check.

### When a run cannot finish

Every section that says "stop and report" ends here. Pass no outputs and a `reason` from this
closed set - `report` rejects anything else, because the workflow branches on the value and cannot
be handed free text:

`missing-input`, `another-format-preferred`, `ambiguous-pd-template`, `source-too-large`,
`stage-byte-mismatch`, `no-text-extracted`, `no-fields-found`, `no-archive-mechanism`,
`archived-not-uploaded`, `upload-failed`, `byte-mismatch`, `path-not-dereferenced`

Put the specifics in `notes` - which template, which field, which byte counts. The code says what
kind of failure it was; the note says what happened.

