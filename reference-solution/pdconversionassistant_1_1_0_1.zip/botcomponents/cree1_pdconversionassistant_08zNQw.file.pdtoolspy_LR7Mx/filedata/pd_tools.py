#!/usr/bin/env python3
"""
pd_tools.py - deterministic helper for PD/AD template conversion.

Every subcommand prints exactly ONE JSON object to stdout and nothing else, so the
caller branches on data rather than parsing prose.

SUBCOMMANDS
-----------
  inspect       Discover fillable fields in a .docx: content controls, {{tokens}},
                and plain blanks named by the label beside or above them.
  variants      Report the alternative blocks a template offers.
  fill          Fill a template from a JSON map, repackage, report byte counts.
  verify        Re-open a .docx, confirm it is a valid package, report sizes.
  sources       Group a folder listing into convertible documents: pair the same
                document held as both .pdf and .docx, and pick which to convert.
  destination   Work out where a conversion goes. The filled document replaces the
                source in the position folder; --output ad puts it in the
                AD Documents subfolder instead, displacing nothing.
  archive-name  Name a displaced document, stamped so a whole group shares one.
  report        Assemble and validate the run report the workflow parses.

EXIT CODES
----------
  0  success
  2  usage / input error
  4  upload failed, or bytes stored != bytes sent

Why the design is the way it is - measured platform limits, abandoned approaches
and the failures each rule prevents - is in docs/DESIGN-LOG.md.
"""

import argparse
import base64
import copy
import hashlib
import json
import os
import re
import sys
import time
import zipfile

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
XML_SPACE = "{http://www.w3.org/XML/1998/namespace}space"
XML_DECL = b'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\r\n'


try:
    from lxml import etree as ET
    LXML = True
except ImportError:  # pragma: no cover - lxml ships with python-docx
    import xml.etree.ElementTree as ET
    LXML = False
    ET.register_namespace("w", W)

TOKEN_RE = re.compile(r"\{\{\s*([A-Za-z0-9_.\-][A-Za-z0-9_.\- ]*?)\s*\}\}")
FILLABLE_PARTS = re.compile(
    r"^word/(document\.xml|header\d*\.xml|footer\d*\.xml)$"
)

# SharePoint / OneDrive naming constraints
ILLEGAL_CHARS = '"*:<>?/\\|'
RESERVED_NAMES = {
    "con", "prn", "aux", "nul", "desktop.ini", ".lock", "_vti_",
}
RESERVED_NAMES |= {"com%d" % i for i in range(10)}
RESERVED_NAMES |= {"lpt%d" % i for i in range(10)}
MAX_SEGMENT = 200          # conservative; SharePoint allows more
MAX_PATH = 400             # SharePoint hard limit on full server-relative path
ARCHIVE_FOLDER_NAME = "Archive"      # superseded documents, one per output folder
AD_FOLDER_NAME = "AD Documents"      # AD output, inside the position folder
OUTPUT_EXT = ".docx"                 # output is always Word, whatever the source was

# Everything this tool writes goes into one of these subfolders of the position
# folder. Sources always sit at the top level of the position folder, so "is this
# a source?" reduces to "is it outside these?" - no marker column, no filename
# convention, and it extends to any future output folder by adding a name here.
OUTPUT_FOLDERS = (ARCHIVE_FOLDER_NAME, AD_FOLDER_NAME)

CONVERTIBLE_EXT = (".pdf", ".docx")  # what may be treated as a source document



def qn(tag):
    prefix, local = tag.split(":")
    return "{%s}%s" % ({"w": W}[prefix], local)


def parse(data):
    return ET.fromstring(data)


def serialize(root):
    if LXML:
        body = ET.tostring(root, xml_declaration=False, encoding="UTF-8")
    else:
        body = ET.tostring(root, encoding="unicode").encode("utf-8")
    return XML_DECL + body


def out(obj, code=0):
    """Print exactly one JSON object, in pure ASCII.

    ensure_ascii=True is deliberate. Real templates carry curly quotes, en dashes
    and non-breaking spaces, and stdout on Windows defaults to cp1252 - so with
    ensure_ascii=False those characters go out as cp1252 bytes and a caller
    decoding the result as UTF-8 cannot parse it. Escaping sidesteps the console
    encoding entirely, and the escapes decode back to the same characters.
    """
    sys.stdout.write(json.dumps(obj, ensure_ascii=True) + "\n")
    return code


def sha(data):
    return hashlib.sha256(data).hexdigest()


# ---------------------------------------------------------------- package I/O

def read_parts(path):
    """Return (infolist, [bytes]) preserving duplicate/oddball entries."""
    with zipfile.ZipFile(path, "r") as zin:
        infos = zin.infolist()
        raw = [zin.open(i).read() for i in infos]
    return infos, raw


def repack(infos, raw, replacements, out_path, level):
    """Rewrite every entry, substituting replacements by filename.

    Non-standard entries (e.g. the [trash] padding entries observed in the
    customer's template) are carried through untouched so the package stays faithful.
    """
    kw = {}
    if sys.version_info >= (3, 7):
        kw["compresslevel"] = level
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED, **kw) as zout:
        for info, payload in zip(infos, raw):
            data = replacements.get(info.filename, payload)
            zi = zipfile.ZipInfo(info.filename, date_time=info.date_time)
            zi.external_attr = info.external_attr
            zi.create_system = info.create_system
            zi.compress_type = zipfile.ZIP_DEFLATED
            # Passing a ZipInfo makes writestr ignore the ZipFile-level
            # compresslevel - ZipInfo._compresslevel defaults to None and wins.
            # Without this line both level 1 and level 9 produce byte-identical
            # output, which is why a measured run reported 44,784 -> 44,784.
            zi._compresslevel = level
            zout.writestr(zi, data)
    return os.path.getsize(out_path)


# ------------------------------------------------------------- field handling

def iter_sdt(root):
    """Yield (sdt, sdtContent, name) for every content control."""
    for sdt in root.iter(qn("w:sdt")):
        pr = sdt.find(qn("w:sdtPr"))
        content = sdt.find(qn("w:sdtContent"))
        if pr is None or content is None:
            continue
        name = None
        for probe in ("w:tag", "w:alias"):
            el = pr.find(qn(probe))
            if el is not None and el.get(qn("w:val")):
                name = el.get(qn("w:val"))
                break
        yield sdt, content, name


def element_text(el):
    return "".join(t.text or "" for t in el.iter(qn("w:t")))


# Highlighting carries two opposite meanings in a finished document, so they must
# not share a colour. A template highlights blanks to show where to type, and all
# of that has to be gone from an issued document. A gap we could not answer has to
# be visible for the opposite reason - somebody must go and fill it in.
#
# So gaps get their own colour, and stripping leaves it alone. Nothing else in the
# pipeline needs to know the order things ran in.
GAP_HIGHLIGHT = "cyan"


def strip_highlight(rpr):
    """Remove template highlighting, but never a gap marker this run applied."""
    if rpr is None:
        return
    for tag in ("w:highlight", "w:shd"):
        for el in list(rpr.findall(qn(tag))):
            if el.get(qn("w:val")) == GAP_HIGHLIGHT:
                continue
            rpr.remove(el)


def mark_gap(p):
    """Leave a blank unfilled and make it visible.

    The template already says what belongs here, so its own placeholder text stays
    exactly as written and is highlighted instead of replaced. Writing words like
    "Not provided" into the document would ship our vocabulary to the customer
    inside their position description; a highlighted blank says the same thing in
    the language the template already uses, and a reviewer can type straight over
    it.
    """
    for r in p.findall(qn("w:r")):
        rpr = r.find(qn("w:rPr"))
        if rpr is None:
            rpr = ET.Element(qn("w:rPr"))
            r.insert(0, rpr)
        for el in list(rpr.findall(qn("w:highlight"))):
            rpr.remove(el)
        h = ET.SubElement(rpr, qn("w:highlight"))
        h.set(qn("w:val"), GAP_HIGHLIGHT)


def write_lines(run, rpr, value):
    """Put text into one run, turning newlines into Word line breaks.

    A line break keeps the text inside the SAME paragraph. That is what we want
    for ordinary prose, but not for a bullet - see fill_paragraph.
    """
    for child in list(run):
        run.remove(child)
    if rpr is not None:
        run.append(rpr)
    lines = str(value).split("\n")
    for idx, line in enumerate(lines):
        if idx:
            ET.SubElement(run, qn("w:br"))
        t = ET.SubElement(run, qn("w:t"))
        t.set(XML_SPACE, "preserve")
        t.text = line


def parent_map(root):
    """Work out each element's parent.

    ElementTree has no "who is my parent?" method, and we need one to insert a
    new paragraph next to an existing one.
    """
    return {child: parent for parent in root.iter() for child in parent}


def has_numbering(ppr):
    """True if these paragraph properties attach a real numbered list.

    A w:numPr is not enough on its own. Word writes one carrying only a w:ilvl to
    set an outline level - the stock Subtitle style does exactly this - and writes
    numId="0" to strip numbering that would otherwise be inherited. Neither is a
    bullet, and treating them as one would split ordinary paragraphs into pieces.
    """
    if ppr is None:
        return False
    npr = ppr.find(qn("w:numPr"))
    if npr is None:
        return False
    num_id = npr.find(qn("w:numId"))
    return num_id is not None and (num_id.get(qn("w:val")) or "0") != "0"


LIST_STYLE_IDS = set()


def set_list_styles(styles_xml):
    """Record which paragraph styles carry numbering, from word/styles.xml.

    Word has two ways to make a bullet. Clicking the bullet button stamps a
    w:numPr onto the paragraph itself; applying a style such as "List Bullet"
    leaves the paragraph bare and puts the numbering in the style definition.
    Only the first is visible on the paragraph, so checking there alone misses
    every style-driven bullet - and a template built that way silently gets one
    enormous bullet instead of one per line, which is the exact failure the
    splitting in fill_paragraph exists to prevent.

    basedOn chains are followed, so a style inheriting from a numbered style
    counts too.
    """
    LIST_STYLE_IDS.clear()
    try:
        root = parse(styles_xml)
    except Exception:
        return LIST_STYLE_IDS

    numbered, based_on = set(), {}
    for st in root.findall(qn("w:style")):
        if st.get(qn("w:type")) not in (None, "paragraph"):
            continue
        sid = st.get(qn("w:styleId"))
        if not sid:
            continue
        if has_numbering(st.find(qn("w:pPr"))):
            numbered.add(sid)
        parent = st.find(qn("w:basedOn"))
        if parent is not None:
            based_on[sid] = parent.get(qn("w:val"))

    # walk each style up its basedOn chain until it hits a numbered ancestor
    for sid in list(based_on):
        seen, cur = set(), sid
        while cur in based_on and cur not in seen:
            seen.add(cur)
            cur = based_on[cur]
            if cur in numbered:
                numbered.add(sid)
                break

    LIST_STYLE_IDS.update(numbered)
    return LIST_STYLE_IDS


def is_list_paragraph(p):
    """True if Word draws this paragraph as a bullet or a numbered item."""
    if has_numbering(p.find(qn("w:pPr"))):
        return True
    return para_style(p) in LIST_STYLE_IDS


def fill_one_paragraph(p, value):
    """Put value into a single paragraph, keeping that paragraph's formatting.

    The paragraph's existing runs are collapsed into one so the text comes out in
    a single font rather than inheriting fragments of the placeholder's styling.
    The first run's formatting is what survives, minus any highlighting.
    """
    runs = p.findall(qn("w:r"))
    if not runs:
        run = ET.SubElement(p, qn("w:r"))
        write_lines(run, None, value)
        return
    first = runs[0]
    rpr = first.find(qn("w:rPr"))
    strip_highlight(rpr)
    for extra in runs[1:]:
        p.remove(extra)
    write_lines(first, rpr, value)


def fill_paragraph(p, value, parents=None):
    """Put value into a paragraph, splitting a bulleted list into real bullets.

    Why this is not as simple as it looks. Many blanks in a position-description
    template sit inside a bulleted list, and the value we fill them with is often
    a list itself - a dozen accountabilities, one per line. If we wrote those
    lines into the single paragraph we found, Word would render ONE enormous
    bullet with a dozen lines crammed inside it.

    So when the value has several lines AND the paragraph is a bullet, we copy the
    paragraph once per line. Each copy keeps the original's paragraph properties -
    including its numbering - so Word renders a proper bullet for every line.

    Anything else (ordinary prose, a table cell) keeps its line breaks and stays
    in one paragraph, which is the correct look there.
    """
    lines = str(value).split("\n")
    if len(lines) > 1 and parents is not None and is_list_paragraph(p):
        parent = parents.get(p)
        if parent is not None:
            blank = copy.deepcopy(p)          # the empty bullet, before filling
            position = list(parent).index(p)
            fill_one_paragraph(p, lines[0])
            for offset, line in enumerate(lines[1:], start=1):
                extra_bullet = copy.deepcopy(blank)
                fill_one_paragraph(extra_bullet, line)
                parent.insert(position + offset, extra_bullet)
            return
    fill_one_paragraph(p, value)


def fill_sdt(content, value):
    """Fill a content control. Returns True only if it was actually filled."""
    paras = content.findall(qn("w:p"))
    if paras:
        for extra in paras[1:]:
            content.remove(extra)
        fill_paragraph(paras[0], value)
        return True
    runs = content.findall(qn("w:r"))
    if runs:
        first = runs[0]
        rpr = first.find(qn("w:rPr"))
        strip_highlight(rpr)
        for extra in runs[1:]:
            content.remove(extra)
        write_lines(first, rpr, value)
        return True
    # Block-level content we do not know how to replace safely - most often a
    # w:tbl. Appending a bare w:r here would be schema-invalid AND would leave
    # the original content in place, so refuse instead. The caller reports it
    # in fields_unmatched, which is loud rather than silent.
    return False


def discover(root):
    controls, tokens = [], []
    for _, content, name in iter_sdt(root):
        controls.append({
            "name": name,
            "current_text": element_text(content)[:200],
        })
    for p in root.iter(qn("w:p")):
        joined = element_text(p)
        for hit in TOKEN_RE.findall(joined):
            token = hit.strip()
            if token not in tokens:
                tokens.append(token)
    return controls, tokens


def set_node_text(run, t, text):
    """Set one w:t's text, expanding newlines into <w:br/> siblings in place."""
    if "\n" not in text:
        t.text = text
        t.set(XML_SPACE, "preserve")
        return
    idx = list(run).index(t)
    run.remove(t)
    for i, part in enumerate(text.split("\n")):
        if i:
            run.insert(idx, ET.Element(qn("w:br")))
            idx += 1
        nt = ET.Element(qn("w:t"))
        nt.set(XML_SPACE, "preserve")
        nt.text = part
        run.insert(idx, nt)
        idx += 1


def fill_tokens(p, mapping):
    """Replace {{tokens}} in a paragraph, rewriting ONLY the runs that carry them.

    Word routinely fragments {{Location}} into {{Loc + ation}}, so the search
    runs over the joined text - but the edit is applied per w:t node. Everything
    else in the paragraph survives: tabs (w:tab), breaks, hyperlinks, images,
    field codes, and the per-run formatting of untouched runs.

    The previous implementation collapsed the whole paragraph into a single run
    carrying run[0]'s formatting, which silently deleted tabs and every other
    non-w:t child. That is exactly the corruption this skill exists to prevent.
    """
    nodes, pos = [], 0
    for r in p.findall(qn("w:r")):
        for t in r.findall(qn("w:t")):
            txt = t.text or ""
            nodes.append((pos, pos + len(txt), r, t, txt))
            pos += len(txt)
    if not nodes:
        return []

    joined = "".join(n[4] for n in nodes)
    edits, touched = [], []
    for m in TOKEN_RE.finditer(joined):
        key = m.group(1).strip()
        if key in mapping:
            edits.append((m.start(), m.end(), str(mapping[key])))
            if key not in touched:
                touched.append(key)
    if not edits:
        return []

    starts = {s: v for s, _, v in edits}
    dropped = set()
    for s, e, _ in edits:
        dropped.update(range(s, e))

    for start, end, run, t, txt in nodes:
        pieces, changed = [], False
        for i in range(start, end):
            if i in starts:
                pieces.append(starts[i])
                changed = True
            if i in dropped:
                changed = True
                continue
            pieces.append(joined[i])
        if changed:
            strip_highlight(run.find(qn("w:rPr")))
            set_node_text(run, t, "".join(pieces))
    return touched


def apply_map(root, mapping):
    """Fill content controls, then {{tokens}}, then heading-anchored placeholders.

    Returns (filled, missing).
    """
    filled, gapped, seen = [], [], set()
    # Recorded up front: filling a bulleted blank inserts new paragraphs, and we
    # need to know where to put them.
    parents = parent_map(root)

    for _, content, name in iter_sdt(root):
        if name and name in mapping and name not in seen:
            if fill_sdt(content, mapping[name]):
                filled.append(name)
                seen.add(name)

    for p in root.iter(qn("w:p")):
        for key in fill_tokens(p, mapping):
            if key not in seen:
                filled.append(key)
                seen.add(key)

    by_index = {i: el for i, el, _, _ in iter_outline_paragraphs(root)}
    for key, value in mapping.items():
        m = INDEX_KEY.match(key)
        if not m or key in seen:
            continue
        para = by_index.get(int(m.group(1)))
        if para is None:
            continue
        if value is None:
            mark_gap(para)
            gapped.append(key)
        else:
            fill_paragraph(para, value, parents)
            filled.append(key)
        seen.add(key)

    for name, para, _ in list(iter_anchored(root)):
        if name in mapping and name not in seen:
            if mapping[name] is None:
                mark_gap(para)
                gapped.append(name)
            else:
                fill_paragraph(para, mapping[name], parents)
                filled.append(name)
            seen.add(name)

    missing = [k for k in mapping if k not in seen]
    return filled, missing, gapped


# ------------------------------------------- anchored (unnamed) placeholders
#
# Some templates have no content controls and no {{tokens}} - their blanks are
# literal text a human is expected to overtype. Those blanks are still
# addressable: each one is introduced by something that names it, either a label
# cell beside it in a table or a heading paragraph above it. That label is the
# field name, so a map can key on it without positional guessing.
#
# Nothing below knows any specific template's wording. Field names, headings and
# labels are all read from whatever document is passed in. The only assumptions
# are formatting conventions - "a blank looks like <...>, [...], xxx or ___" and
# "a label ends with a colon" - and both are overridable from the command line.

# Conventions for "this is a blank", not any one template's wording:
#   <enter value>, <name>      angle-bracket instruction
#   [insert], [ ]              square-bracket instruction
#   xxx, XXXX, nnn             repeated placeholder letters
#   ___, ....                  rules and leaders
DEFAULT_PLACEHOLDER = (
    r"<[^<>]{0,60}>"
    r"|\[[^\[\]]{0,60}\]"
    r"|(?:x{3,}|n{3,})"
    r"|_{3,}"
    r"|\.{4,}"
)
LABEL_RE = re.compile(r"^(.{2,80}?)\s*:\s*$")

_placeholder_re = None


def placeholder_re():
    global _placeholder_re
    if _placeholder_re is None:
        set_placeholder(DEFAULT_PLACEHOLDER)
    return _placeholder_re


def set_placeholder(pattern):
    """Install the blank-detection pattern. Anchored at the start of a run."""
    global _placeholder_re
    _placeholder_re = re.compile(r"^\s*(?:%s)\s*" % pattern, re.I)
    return _placeholder_re


def para_text(p):
    return "".join(t.text or "" for t in p.iter(qn("w:t"))).strip()


def para_style(p):
    pr = p.find(qn("w:pPr"))
    if pr is None:
        return ""
    st = pr.find(qn("w:pStyle"))
    return st.get(qn("w:val"), "") if st is not None else ""


def placeholder_match(text):
    """Return the matched placeholder string, or None."""
    m = placeholder_re().match(text.strip())
    return m.group(0).strip() if m else None


def anchor_name(text):
    m = LABEL_RE.match(text.strip())
    return (m.group(1) if m else text.strip()).strip()


def iter_anchored(root):
    """Yield (field_name, paragraph, placeholder_text) for each addressable blank.

    Names are made unique by appending #2, #3 ... so a template that repeats a
    heading still produces a deterministic, one-to-one map.
    """
    body = root.find(qn("w:body"))
    if body is None:
        return
    used = {}

    def unique(name):
        used[name] = used.get(name, 0) + 1
        return name if used[name] == 1 else "%s#%d" % (name, used[name])

    def walk(container, heading):
        for el in list(container):
            if el.tag == qn("w:p"):
                text = para_text(el)
                if not text:
                    continue
                found = placeholder_match(text)
                if found:
                    if heading[0]:
                        yield unique(heading[0]), el, found
                else:
                    heading[0] = anchor_name(text)
            elif el.tag == qn("w:tbl"):
                for row in el.findall(qn("w:tr")):
                    cells = row.findall(qn("w:tc"))
                    # label/value rows: left cell names the right cell's blank
                    if len(cells) == 2:
                        label = "".join(para_text(p)
                                        for p in cells[0].findall(qn("w:p")))
                        vparas = cells[1].findall(qn("w:p"))
                        vtext = "".join(para_text(p) for p in vparas)
                        found = placeholder_match(vtext)
                        if label and vparas and found:
                            yield unique(anchor_name(label)), vparas[0], found
                            continue
                    for cell in cells:
                        for item in walk(cell, heading):
                            yield item

    for item in walk(body, [None]):
        yield item


# ------------------------------------------------------- template variants
#
# Some templates ship several complete alternatives plus an instruction page and
# expect a human to delete the ones they do not need. Choosing is a judgement
# call; executing the cut is not, so the helper does the cutting once the caller
# names the variant.
#
# Nothing here knows any specific template's wording. Markers are found by a
# convention ("a short line naming a numbered alternative"), and the point where
# each alternative's real content begins is found by alignment: alternatives are
# parallel structures, so the first place they start saying the same thing is
# where the boilerplate ends. Both are overridable from the command line.

DEFAULT_VARIANT_MARKER = r"^\s*(?:template|option|variant|version)\s*(\d+)\s*[:.\-]?\s*$"
ALIGN_RUN = 3  # consecutive matching paragraphs required to trust an alignment

_variant_re = None


def variant_re():
    global _variant_re
    if _variant_re is None:
        set_variant_marker(DEFAULT_VARIANT_MARKER)
    return _variant_re


def set_variant_marker(pattern):
    global _variant_re
    _variant_re = re.compile(pattern, re.I)
    return _variant_re


def _texts_after(kids, start, end):
    """[(body_index, text)] for non-empty paragraphs in a range."""
    got = []
    for j in range(start, end):
        if kids[j].tag == qn("w:p"):
            t = para_text(kids[j])
            if t:
                got.append((j, t))
    return got


SNAP_WINDOW = 5  # unstyled paragraphs to look past when snapping to content


def _snap_to_styled(kids, start, end):
    """Skip trailing unstyled boilerplate to the first styled paragraph.

    Instructions to the reader are ordinary body text; the document proper opens
    with a styled heading. Bounded to a few paragraphs so real unstyled content
    can never be cut. Structural only - nothing here reads the wording.
    """
    seen = 0
    for j in range(start, end):
        if kids[j].tag != qn("w:p"):
            break
        text = para_text(kids[j])
        if not text:
            continue
        if para_style(kids[j]):
            return j
        seen += 1
        if seen > SNAP_WINDOW:
            break
    return start


def _run_length(blocks, positions):
    """How many consecutive paragraphs agree across all variants from here."""
    n = 0
    while all(pos + n < len(b) for b, pos in zip(blocks, positions)):
        texts = {b[pos + n][1].casefold() for b, pos in zip(blocks, positions)}
        if len(texts) != 1:
            break
        n += 1
    return n


def _align_content_start(blocks):
    """Find where parallel alternatives begin agreeing with each other.

    blocks is a list of [(index, text)] - one per variant. Returns
    ([body index per variant], run_length) or (None, 0).

    Alternatives share two things: a short block of instructions telling the
    reader which one to keep, and then the whole document body. Both align, so
    the first agreement is not the answer - the longest one is. That distinction
    is what keeps boilerplate out of the selected output without naming it.
    """
    if len(blocks) < 2 or not all(blocks):
        return None, 0
    first = blocks[0]
    best, best_run = None, 0
    for a, (idx, text) in enumerate(first):
        positions, ok = [a], True
        for other in blocks[1:]:
            hits = [b for b, (_, t) in enumerate(other)
                    if t.casefold() == text.casefold()]
            if not hits:
                ok = False
                break
            positions.append(max(hits, key=lambda h: _run_length(
                [first, other], [a, h])))
        if not ok:
            continue
        run = _run_length(blocks, positions)
        if run > best_run:
            best_run = run
            best = [b[p][0] for b, p in zip(blocks, positions)]
    if best_run < ALIGN_RUN:
        return None, 0
    return best, best_run


def find_variants(root, content_start=None):
    """Return ([{number, marker_index, content_index, end_index, applies_to,
    content_starts_with, detected_by}], body)."""
    body = root.find(qn("w:body"))
    if body is None:
        return [], None
    kids = list(body)
    marks = []
    for i, el in enumerate(kids):
        if el.tag != qn("w:p"):
            continue
        m = variant_re().match(para_text(el))
        if m:
            marks.append((i, int(m.group(1)) if m.groups() else len(marks) + 1))
    if not marks:
        return [], body

    spans = [(idx, marks[p + 1][0] if p + 1 < len(marks) else len(kids))
             for p, (idx, _) in enumerate(marks)]
    blocks = [_texts_after(kids, s + 1, e) for s, e in spans]

    starts, run = _align_content_start(blocks)
    how = "alignment(run=%d)" % run
    if starts is not None:
        snapped = [_snap_to_styled(kids, s, spans[p][1])
                   for p, s in enumerate(starts)]
        if snapped != starts:
            how += "+snap"
        starts = snapped
    else:
        # single alternative, or alternatives that are not parallel: fall back to
        # the first heading-styled paragraph, then to the marker itself
        how, starts = "heading-style", []
        for pos, (s, e) in enumerate(spans):
            pick = next((j for j in range(s + 1, e)
                         if kids[j].tag == qn("w:p")
                         and para_style(kids[j]).lower().startswith("heading")
                         and para_text(kids[j])), None)
            if pick is None:
                how, pick = "marker", s + 1
            starts.append(pick)

    if content_start:
        # explicit operator override, for a template the detectors misread
        rx = re.compile(content_start, re.I)
        picked = []
        for pos, (s, e) in enumerate(spans):
            hit = next((j for j, t in blocks[pos] if rx.search(t)), None)
            picked.append(hit if hit is not None else starts[pos])
        starts, how = picked, "content-start override"

    variants = []
    for pos, (idx, number) in enumerate(marks):
        s, e = spans[pos]
        content = starts[pos]
        applies = next((t for j, t in blocks[pos] if j < content), None)
        variants.append({
            "number": number,
            "marker_index": idx,
            "content_index": content,
            "end_index": e,
            "applies_to": applies[:200] if applies else None,
            "content_starts_with": para_text(kids[content])[:80]
                                   if kids[content].tag == qn("w:p") else None,
            "detected_by": how,
        })
    return variants, body


def cmd_variants(args):
    if not os.path.isfile(args.docx):
        return out({"status": "ERROR", "reason": "file not found",
                    "path": args.docx}, 2)
    infos, raw = read_parts(args.docx)
    doc = next((p for i, p in zip(infos, raw)
                if i.filename == "word/document.xml"), None)
    if doc is None:
        return out({"status": "ERROR", "reason": "no word/document.xml"}, 2)
    variants, _ = find_variants(parse(doc), getattr(args, "content_start", None))
    if not variants:
        return out({
            "status": "OK", "variants": [], "variant_count": 0,
            "note": "no numbered alternatives found - fill the document as-is",
            "marker_pattern": variant_re().pattern,
            "action": "if this template does mark alternatives some other way, "
                      "re-run with --variant-marker",
        })
    return out({
        "status": "OK",
        "variant_count": len(variants),
        "marker_pattern": variant_re().pattern,
        "variants": [{"number": v["number"],
                      "applies_to": v["applies_to"],
                      "content_starts_with": v["content_starts_with"],
                      "detected_by": v["detected_by"]}
                     for v in variants],
        "action": "for information only - every variant is filled, so there is "
                  "nothing to choose. Fill the '#2' field names reported by "
                  "`inspect` alongside the plain ones.",
    })


# ----------------------------------------------------------------- subcommands

def cmd_inspect(args):
    if not os.path.isfile(args.docx):
        return out({"status": "ERROR", "reason": "file not found",
                    "path": args.docx}, 2)
    infos, raw = read_parts(args.docx)
    parts, all_controls, all_tokens = [], [], []
    anchored, variants, doc_outline = [], [], []
    for info, payload in zip(infos, raw):
        if not FILLABLE_PARTS.match(info.filename):
            continue
        try:
            root = parse(payload)
            controls, tokens = discover(root)
        except Exception as exc:
            parts.append({"part": info.filename, "error": str(exc)})
            continue
        if info.filename == "word/document.xml":
            anchored = [{"field": n, "placeholder": ph}
                        for n, _, ph in iter_anchored(root)]
            doc_outline = outline(root)
            variants = [{"number": v["number"],
                         "applies_to": v["applies_to"],
                         "detected_by": v["detected_by"]}
                        for v in find_variants(root, getattr(args, "content_start", None))[0]]
        if not controls and not tokens:
            continue
        parts.append({"part": info.filename,
                      "content_controls": controls,
                      "tokens": tokens})
        all_controls += [c["name"] for c in controls if c["name"]]
        all_tokens += tokens
    names = sorted(set(all_controls) | set(all_tokens))
    result = {
        "status": "OK",
        "file": os.path.basename(args.docx),
        "bytes": os.path.getsize(args.docx),
        "zip_entries": len(infos),
        "non_standard_entries": [i.filename for i in infos
                                 if not i.filename.replace("\\", "/").startswith(
                                     ("word/", "docProps/", "_rels/", "customXml/",
                                      "[Content_Types]"))],
        "parts": parts,
        "field_names": names,
        "anchored_fields": [a["field"] for a in anchored],
        "anchored_detail": anchored,
        "placeholder_pattern": placeholder_re().pattern,
        "variants": variants,
        "outline": doc_outline,
    }
    if variants:
        result["next"] = ("this template offers %d alternatives and every one is "
                          "filled - map ALL the field names above, including the "
                          "'#2' copies. Do not drop a variant."
                          % len(variants))
    elif not names and anchored:
        result["next"] = ("no content controls or tokens, but %d label-addressable "
                          "blanks were found - key the map on anchored_fields. "
                          "Check anchored_detail: the field is the label read from "
                          "the document, the placeholder is the blank it matched."
                          % len(anchored))
    elif not names and not anchored:
        result["next"] = ("no fillable fields of any kind found. If this document "
                          "does have blanks, they use a convention the default "
                          "pattern misses - re-run with --placeholder")
    return out(result)


def cmd_fill(args):
    for path in (args.docx, args.map):
        if not os.path.isfile(path):
            return out({"status": "ERROR", "reason": "file not found",
                        "path": path}, 2)
    with open(args.map, "r", encoding="utf-8") as fh:
        mapping = json.load(fh)
    if not isinstance(mapping, dict):
        return out({"status": "ERROR",
                    "reason": "map must be a JSON object of field -> value"}, 2)
    # keys beginning with "_" are comments, not fields
    mapping = {k: v for k, v in mapping.items() if not k.startswith("_")}

    infos, raw = read_parts(args.docx)
    styles = next((pay for inf, pay in zip(infos, raw)
                   if inf.filename == "word/styles.xml"), None)
    if styles is not None:
        set_list_styles(styles)
    replacements, filled, gapped, missing = {}, [], [], set(mapping)
    scanned, skipped = [], []
    for info, payload in zip(infos, raw):
        if not FILLABLE_PARTS.match(info.filename):
            if info.filename.endswith(".xml") and info.filename.startswith("word/"):
                skipped.append(info.filename)
            continue
        scanned.append(info.filename)
        root = parse(payload)
        done, _, gaps = apply_map(root, mapping)
        # A part holding only gaps still changed - the markers were applied to it.
        # Writing it back only when something was FILLED would silently discard
        # them, and the document would come out looking complete.
        if done or gaps:
            replacements[info.filename] = serialize(root)
            filled += done
            gapped += gaps
            missing -= set(done) | set(gaps)

    if not replacements:
        return out({"status": "ERROR",
                    "reason": "no fields matched; run inspect first",
                    "map_keys": sorted(mapping)}, 2)


    tmp = args.out + ".lvl0"
    size_plain = repack(infos, raw, replacements, tmp, 1)
    size_max = repack(infos, raw, replacements, args.out, 9)
    os.remove(tmp)

    data = open(args.out, "rb").read()
    b64_len = len(base64.b64encode(data))
    valid, detail = validate(args.out)

    return out({
        "status": "OK" if valid else "ERROR",
        "output": args.out,
        "fields_filled": sorted(set(filled)),
        "fields_gapped": sorted(set(gapped)),
        "fields_unmatched": sorted(missing),
        "parts_scanned": scanned,
        "parts_not_scanned": skipped,
        "unmatched_note": ("only document.xml, headers and footers are filled; "
                           "an unmatched name that inspect DID report may live "
                           "in a part listed under parts_not_scanned"),
        "template_bytes": os.path.getsize(args.docx),
        "bytes_before_max_compression": size_plain,
        "bytes_after_max_compression": size_max,
        "final_bytes_to_send": len(data),
        "base64_chars": b64_len,
        "sha256": sha(data),
        "package_valid": valid,
        "package_detail": detail,
        "upload_path": os.path.abspath(args.out),
        "next": ("pass upload_path as create_file's `body` - the bare absolute "
                 "path, no @ prefix, no file://, no quotes. The connector opens "
                 "it. Never put base64 in body."),
    }, 0 if valid else 2)


def validate(path):
    try:
        with zipfile.ZipFile(path, "r") as zf:
            bad = zf.testzip()
            if bad:
                return False, "corrupt entry: %s" % bad
            if "word/document.xml" not in zf.namelist():
                return False, "word/document.xml missing"
            parse(zf.read("word/document.xml"))
    except Exception as exc:
        return False, str(exc)
    try:
        import docx  # noqa: F401
        docx.Document(path)
        return True, "opened by python-docx"
    except ImportError:
        return True, "zip + xml valid (python-docx unavailable)"
    except AttributeError as exc:
        # Observed in this sandbox: python-docx/lxml import fine but blow up at
        # call time (getargspec, removed in modern Python). That is a broken
        # environment, not a broken document - do not fail the package for it.
        return True, "zip + xml valid (python-docx broken: %s)" % exc
    except Exception as exc:
        if "getargspec" in str(exc) or "inspect" in str(exc):
            return True, "zip + xml valid (python-docx broken: %s)" % exc
        return False, "python-docx rejected: %s" % exc


# ------------------------------------------------- destination folder naming

def decode_path(value, strict=False):
    """Accept a resolved SharePoint path/webUrl; return decoded segments.

    strict=True rejects the URL shapes that do NOT contain a real folder path.
    A short sharing link (`/:w:/r/...`), a `_layouts/15/Doc.aspx?sourcedoc=...`
    link, or an `_api` URL all parse into plausible-looking nonsense - the old
    version happily returned `pd_folder_name: "15"` and status OK, silently
    aiming the upload at the wrong place. Resolve the link with
    getFileOrFolderMetadataByUrl first and pass the returned webUrl or
    parentReference.path instead.
    """
    try:
        from urllib.parse import unquote, urlparse
    except ImportError:  # pragma: no cover
        from urlparse import urlparse  # type: ignore
        from urllib import unquote     # type: ignore
    raw = value.split("?", 1)[0].split("#", 1)[0]
    if "://" in raw:
        raw = urlparse(raw).path
    raw = unquote(raw).replace("\\", "/")
    segments = [s for s in raw.split("/") if s]

    if strict:
        bad = detect_unresolved(segments)
        if bad:
            raise UnresolvedPathError(bad, segments)
    return segments


class UnresolvedPathError(Exception):
    """The --source value is a link shape, not a resolved folder path."""

    def __init__(self, reason, segments):
        Exception.__init__(self, reason)
        self.reason = reason
        self.segments = segments


SHARING_TOKEN = re.compile(r"^:[a-zA-Z]:$")
NON_PATH_SEGMENTS = {"_layouts", "_api", "_vti_bin", "_vti_history", "guestaccess.aspx"}


def detect_unresolved(segments):
    """Return a reason string if these segments are not a real folder path."""
    lowered = [s.lower() for s in segments]
    for seg, low in zip(segments, lowered):
        if SHARING_TOKEN.match(seg):
            return ("'%s' is a short sharing-link token, not a folder. The path "
                    "after it is not the document's real location." % seg)
        if low in NON_PATH_SEGMENTS:
            return ("'%s' is a SharePoint system path, not a document library "
                    "folder." % seg)
    if lowered and lowered[-1].endswith(".aspx"):
        return ("'%s' is a page URL, not a file path; the real path is in the "
                "sourcedoc parameter." % segments[-1])
    if "sites" not in lowered and "personal" not in lowered and "teams" not in lowered:
        return ("path contains no /sites/, /teams/ or /personal/ segment, so it "
                "is not a resolved server-relative SharePoint path.")
    return None


def sanitise_segment(name, warnings, label):
    """Make one path segment legal for SharePoint. Deterministic."""
    original = name
    cleaned = "".join("-" if ch in ILLEGAL_CHARS else ch for ch in name)
    cleaned = "".join(ch for ch in cleaned if ord(ch) >= 32)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    cleaned = re.sub(r"-{2,}", "-", cleaned)
    cleaned = cleaned.strip(" .-")
    if cleaned.startswith("~$"):
        cleaned = cleaned[2:].strip()
    if cleaned.lower() in RESERVED_NAMES:
        cleaned = cleaned + "-folder"
    if len(cleaned) > MAX_SEGMENT:
        cleaned = cleaned[:MAX_SEGMENT].rstrip(" .")
        warnings.append("%s truncated to %d characters" % (label, MAX_SEGMENT))
    if not cleaned:
        cleaned = "Converted"
        warnings.append("%s was empty after sanitising; used 'Converted'" % label)
    if cleaned != original:
        warnings.append("%s sanitised: %r -> %r" % (label, original, cleaned))
    return cleaned


def make_stamp(modified_iso=None):
    """A YYYYMMDD-HHMMSS stamp, from an ISO timestamp if one is given.

    Timezone parsing is avoided deliberately - SharePoint returns UTC, and pulling
    the digits out survives every ISO variant (fractional seconds, offsets, 'Z').
    """
    digits = re.sub(r"[^0-9]", "", modified_iso or "")
    if len(digits) >= 14:
        return digits[:8] + "-" + digits[8:14]
    return time.strftime("%Y%m%d-%H%M%S", time.gmtime())


def archive_filename(name, modified_iso=None, stamp=None):
    """Name a superseded document: <stem>_<stamp><ext>.

    `stamp` is accepted so that several files can be archived under ONE stamp. A
    position folder may hold the same document as both .pdf and .docx; both are
    displaced by a single conversion, and stamping them separately from their own
    modified dates would scatter one event across two timestamps and make the pair
    impossible to reunite later.
    """
    stem, ext = os.path.splitext(name)
    return "%s_%s%s" % (stem, stamp or make_stamp(modified_iso), ext)


def cmd_archive_name(args):
    stamp = args.stamp or make_stamp(args.modified)
    return out({
        "status": "OK",
        "archive_folder_name": ARCHIVE_FOLDER_NAME,
        "original_filename": args.file,
        "archive_filename": archive_filename(args.file, stamp=stamp),
        "stamp": stamp,
        "stamp_source": ("caller-supplied" if args.stamp
                         else "lastModifiedDateTime" if args.modified
                         else "current UTC time"),
        "next": "move the displaced document into the Archive folder under this "
                "name, then write the new conversion to the original name. Pass "
                "this same `stamp` back for every other file displaced by the "
                "same conversion.",
    }, 0)


UPLOAD_OVERHEAD = 2048   # SharePoint may append its own zip entry on ingestion

# Every way a run can end other than OK. The workflow branches on these, so they
# are a closed set: an invented code reaches the caller as an unhandled value and
# is indistinguishable from a code it has simply not been taught yet.
REASON_CODES = (
    "missing-input",            # a required input was absent or unusable
    "another-format-preferred", # section 1b: a different file in the group is the one to convert
    "ambiguous-pd-template",    # section 1a: two templates both look like the position description
    "source-too-large",         # the source could not be read whole
    "stage-byte-mismatch",      # a staged file did not match its reported size
    "no-text-extracted",        # nothing readable came out of the source
    "no-fields-found",          # inspect found no fillable fields, even with --placeholder
    "no-archive-mechanism",     # nothing available to preserve what would be displaced
    "archived-not-uploaded",    # archive copies made, upload never verified
    "upload-failed",            # the upload call itself failed
    "byte-mismatch",            # stored bytes disagree with sent
    "path-not-dereferenced",    # the connector stored the path instead of the file
)


def upload_verdict(sent, stored, path_chars=None):
    """Judge one upload from its byte counts. Returns (verdict, note).

    The connector returns Success even when it never opened the file - it stores
    the path string as the contents instead. The only signal is the size, so the
    numbers decide this, never the status code.
    """
    if sent is None or stored is None:
        return "FAIL", "byte counts missing; an upload without numbers is unverified"
    if path_chars and stored == path_chars:
        return "FAIL", ("stored size equals the length of the path sent - the "
                        "connector stored the path as the contents")
    if stored < sent:
        return "FAIL", "stored fewer bytes than were sent - truncated"
    if stored - sent <= UPLOAD_OVERHEAD:
        return "PASS", ""
    return "CHECK", ("stored exceeds sent by %d bytes, beyond the %d normally added "
                     "on ingestion - download and compare before claiming success"
                     % (stored - sent, UPLOAD_OVERHEAD))


def cmd_report(args):
    """Assemble the run report the workflow parses.

    The model knows what happened; it should not also have to remember the shape
    of the object that says so. A report is the only record of a run, and the
    failures that matter are structural - an omitted `removed` array reads as
    "nothing was deleted", a `null` where a list belongs breaks the caller, and a
    status of OK beside a short byte count claims a delivery that did not happen.

    So the caller supplies facts and this assembles the object: arrays are
    normalised, every upload is judged from its own byte counts against the same
    tolerance, and `status` is OK only when every one of them passed.
    """
    if not os.path.isfile(args.run):
        return out({"status": "ERROR", "reason": "file not found",
                    "path": args.run}, 2)
    try:
        run = json.load(open(args.run, "r", encoding="utf-8"))
    except ValueError as exc:
        return out({"status": "ERROR",
                    "reason": "--run is not valid JSON: %s" % exc}, 2)
    if not isinstance(run, dict):
        return out({"status": "ERROR",
                    "reason": "--run must be a JSON object"}, 2)

    outputs, problems = [], []
    for i, o in enumerate(run.get("outputs") or []):
        if not isinstance(o, dict):
            problems.append("outputs[%d] is not an object" % i)
            continue
        missing = [k for k in ("template", "kind", "destinationFolderPath",
                               "outputFileName") if not o.get(k)]
        if missing:
            problems.append("outputs[%d] is missing %s" % (i, ", ".join(missing)))
        sent, stored = o.get("bytesSent"), o.get("bytesStored")
        verdict, note = upload_verdict(sent, stored, o.get("uploadPathChars"))
        entry = {
            "template": o.get("template", ""),
            "kind": o.get("kind", ""),
            "destinationFolderPath": o.get("destinationFolderPath", ""),
            "outputFileName": o.get("outputFileName", ""),
            "bytesSent": sent,
            "bytesStored": stored,
            "verdict": verdict,
            "missingFields": list(o.get("missingFields") or []),
            "removed": list(o.get("removed") or []),
            "highlightCleared": o.get("highlightCleared") or 0,
            "archivedAs": list(o.get("archivedAs") or []),
        }
        if note:
            entry["verdictNote"] = note
        outputs.append(entry)

    if problems:
        return out({"status": "ERROR", "reason": "incomplete report input",
                    "problems": problems}, 2)

    reason = run.get("reason") or ""
    if reason and reason not in REASON_CODES:
        return out({
            "status": "ERROR",
            "reason": "unknown reason code %r" % reason,
            "valid_reasons": list(REASON_CODES),
            "action": "use one of valid_reasons, or leave reason empty and let the "
                      "byte counts decide. The workflow branches on this value, so "
                      "it cannot be free text.",
        }, 2)
    if not outputs:
        # Only one reason means "nothing to do here"; every other empty run is a
        # failure. Reporting a failed conversion as SKIPPED hides it from whoever
        # counts how many documents were actually produced.
        status = "SKIPPED" if reason == "another-format-preferred" else "FAILED"
        if not reason:
            reason = "no-outputs"
    elif all(o["verdict"] == "PASS" for o in outputs):
        status = "OK"
    else:
        status = "FAILED"
        if not reason:
            reason = "byte-mismatch"

    return out({
        "status": status,
        "reason": reason if status != "OK" else "",
        "sourceFile": run.get("sourceFile", ""),
        "sourceChosenBecause": run.get("sourceChosenBecause", ""),
        "outputs": outputs,
        "notes": run.get("notes", ""),
    }, 0)


def cmd_sources(args):
    """Turn a raw folder listing into the documents that should actually be converted.

    A position folder is not a tidy list of one PD each. It holds shortcuts and
    notes that are not documents at all; it holds Archive/ and AD Documents/ full
    of things this tool wrote earlier; and it routinely holds the SAME position
    description twice, once as a scan and once as Word. Converting a folder file
    by file would convert our own output, try to read a shortcut as a document,
    and produce two competing conversions of one position.

    So the listing is reduced to groups. Each group is one real document, with one
    file chosen to convert and the rest recorded as displaced - they are archived
    alongside it under a single shared stamp, because one conversion supersedes
    all of them at once.

    Grouping is on the exact stem, case-insensitively, within one folder. Nothing
    fuzzier: "Role - PD 2018.pdf" and "Role - PD.docx" stay separate. The two
    mistakes are not symmetric - splitting one document into two costs a wasted
    conversion, while merging two documents into one archives a document nobody
    converted and removes its content from the live folder.

    Choosing within a group prefers the PDF, which is usually the signed version -
    unless the Word file was modified later, in which case someone has actively
    revised it and that revision is the current statement of the role. Always
    taking the PDF would convert a 2018 scan and archive last month\u2019s edit,
    reporting success.
    """
    if not os.path.isfile(args.files):
        return out({"status": "ERROR", "reason": "file not found",
                    "path": args.files}, 2)
    try:
        listing = json.load(open(args.files, "r", encoding="utf-8"))
    except ValueError as exc:
        return out({"status": "ERROR", "reason": "--files is not valid JSON: %s"
                    % exc}, 2)
    if isinstance(listing, dict):
        listing = listing.get("value", listing.get("files", []))
    if not isinstance(listing, list):
        return out({"status": "ERROR",
                    "reason": "--files must be a JSON list of file objects, or an "
                              "object with a 'value' or 'files' list"}, 2)

    def field(entry, *names):
        for n in names:
            if isinstance(entry, dict) and entry.get(n) not in (None, ""):
                return entry[n]
        return ""

    groups, skipped = {}, []
    for entry in listing:
        if not isinstance(entry, dict):
            skipped.append({"entry": repr(entry)[:80],
                            "reason": "not a file object"})
            continue
        name = field(entry, "name", "Name", "{Name}", "FileLeafRef")
        folder = field(entry, "folder", "path", "{Path}", "folderPath")
        modified = field(entry, "modified", "Modified", "lastModifiedDateTime")
        if not name:
            skipped.append({"entry": repr(entry)[:80], "reason": "no name field"})
            continue

        parts = [seg for seg in str(folder).split("/") if seg]
        inside = next((seg for seg in parts if seg in OUTPUT_FOLDERS), None)
        if inside is not None:
            skipped.append({"name": name, "folder": folder,
                            "reason": "inside %r, which holds output this tool "
                                      "wrote" % inside})
            continue

        stem, ext = os.path.splitext(name)
        if ext.lower() not in CONVERTIBLE_EXT:
            skipped.append({"name": name,
                            "reason": "%r is not a convertible document" % ext})
            continue

        key = (str(folder).rstrip("/").lower(), stem.lower())
        groups.setdefault(key, []).append(
            {"name": name, "folder": folder, "ext": ext.lower(),
             "modified": modified, "stem": stem})

    result = []
    for key in sorted(groups):
        files = sorted(groups[key], key=lambda f: f["name"].lower())
        pdfs = [f for f in files if f["ext"] == ".pdf"]
        docs = [f for f in files if f["ext"] == ".docx"]
        if pdfs and docs:
            newest_pdf = max(pdfs, key=lambda f: str(f["modified"]))
            newest_doc = max(docs, key=lambda f: str(f["modified"]))
            if str(newest_doc["modified"]) > str(newest_pdf["modified"]):
                chosen, why = newest_doc, ("the Word file was modified after the "
                                           "PDF, so it is the current revision")
            else:
                chosen, why = newest_pdf, "PDF preferred when neither is newer"
        elif pdfs:
            chosen, why = max(pdfs, key=lambda f: str(f["modified"])), "only a PDF"
        else:
            chosen, why = max(docs, key=lambda f: str(f["modified"])), "only Word"

        result.append({
            "stem": chosen["stem"],
            "folder": chosen["folder"],
            "convert": chosen["name"],
            "convert_modified": chosen["modified"],
            "why": why,
            # Every file in the group, including the chosen one: the conversion
            # supersedes all of them, and they must all be archived under one stamp.
            "displaced": [f["name"] for f in files],
        })

    return out({
        "status": "OK",
        "group_count": len(result),
        "groups": result,
        "skipped": skipped,
        "next": "convert one document per group. Pass `convert` to `destination` "
                "as --source, then archive every name in `displaced` under the "
                "single `stamp` that destination returned.",
    }, 0)


def cmd_destination(args):
    """Work out where a conversion goes, from the source document's own location.

    The destination is never an input. The filled document REPLACES the source in
    the position folder under the name the source had, and whatever it displaced
    moves into Archive/ with a timestamp:

        <position>/Role.docx                          the current PD
        <position>/Archive/Role_20260820-093958.pdf   what it replaced
        <position>/AD Documents/Role - AD.docx        the AD built from the same source
        <position>/AD Documents/Archive/...           superseded ADs

    Two properties fall out of that shape and both are load-bearing.

    Everything this tool writes lands in a SUBFOLDER of the position folder, and
    sources always sit at the top level. So "is this a source, or something we
    produced?" is answered by the path alone - no marker column, no filename
    convention, nothing needing a permission the customer may not have.

    And a position folder holds exactly one live copy of each document, so what is
    in the folder is always the right input for the next run.

    Output is always .docx whatever the source was, so a PDF source yields a Word
    document with the same stem.
    """
    warnings = []
    try:
        segments = decode_path(args.source, strict=not args.allow_unresolved_source)
    except UnresolvedPathError as exc:
        return out({
            "status": "ERROR",
            "reason": "--source is not a resolved SharePoint path: %s" % exc.reason,
            "source": args.source,
            "parsed_segments": exc.segments,
            "action": "resolve the sharing link to a real path first, then pass the "
                      "webUrl (or parentReference.path + name) as --source. Do not "
                      "guess the folder from a sharing link.",
        }, 2)
    if len(segments) < 2:
        return out({"status": "ERROR",
                    "reason": "--source must be a file path with a parent folder",
                    "source": args.source, "segments": segments}, 2)

    source_name = segments[-1]
    pd_segments = segments[:-1]
    pd_folder_name = pd_segments[-1]
    pd_folder_path = "/" + "/".join(pd_segments)

    # Refuse anything already inside our own output structure. Nothing upstream
    # guarantees a library sweep excludes Archive/ or AD Documents/, and a file
    # from either is a previous conversion rather than a position description.
    # Left unchecked it converts cleanly and reports OK, which is the worst
    # outcome available.
    inside = next((seg for seg in pd_segments if seg in OUTPUT_FOLDERS), None)
    if inside is not None:
        return out({
            "status": "ERROR",
            "reason": "the source is inside %r, a folder this tool writes to, so it "
                      "is a previous conversion rather than a position description"
                      % inside,
            "source": args.source,
            "output_folders": list(OUTPUT_FOLDERS),
            "action": "exclude every file whose path contains one of output_folders "
                      "before converting. Only documents at the top level of a "
                      "position folder are sources.",
        }, 2)

    stem, source_ext = os.path.splitext(source_name)
    if source_ext.lower() not in CONVERTIBLE_EXT:
        return out({
            "status": "ERROR",
            "reason": "%r is not a convertible document" % source_ext,
            "source": args.source,
            "convertible": list(CONVERTIBLE_EXT),
            "action": "shortcuts, notes and other files are not position "
                      "descriptions; filter the file list by extension.",
        }, 2)

    base = sanitise_segment(stem, warnings, "output file base")

    # pd replaces the source in place. Every other kind of template gets its own
    # subfolder, so nothing can ever compete for the in-place slot.
    if args.output == "ad":
        dest_path = pd_folder_path + "/" + AD_FOLDER_NAME
        output_file = base + " - AD" + OUTPUT_EXT
    else:
        dest_path = pd_folder_path
        output_file = base + OUTPUT_EXT

    archive_path = dest_path + "/" + ARCHIVE_FOLDER_NAME
    stamp = args.stamp or make_stamp(args.modified)

    # A stamped name inside Archive/ is the longest path a run can produce, so that
    # - not the output file - is what the SharePoint limit is measured against.
    longest = max(len(dest_path) + 1 + len(output_file),
                  len(archive_path) + 1
                  + len(archive_filename(output_file, stamp=stamp)))
    if longest > MAX_PATH:
        warnings.append("full path is %d characters, over the SharePoint limit of %d"
                        % (longest, MAX_PATH))

    result = {
        "status": "OK" if longest <= MAX_PATH else "ERROR",
        "output_kind": args.output,
        "source_file": source_name,
        "source_stem": stem,
        "pd_folder_name": pd_folder_name,
        "pd_folder_path": pd_folder_path,
        "destination_folder_path": dest_path,
        "output_filename": output_file,
        "archive_folder_name": ARCHIVE_FOLDER_NAME,
        "archive_folder_path": archive_path,
        "stamp": stamp,
        # What this conversion pushes aside. For a pd that is the source itself,
        # since the output takes its place and its name. For an ad it is the
        # previous ad of the same name - the source is untouched.
        "displaced_filename": archive_filename(
            output_file if args.output == "ad" else source_name, stamp=stamp),
        "longest_full_path_chars": longest,
        "max_path_chars": MAX_PATH,
        "warnings": warnings,
    }
    if args.output == "ad":
        result["next"] = (
            "if an AD of this name already exists, move it into archive_folder_path "
            "under its own archive-name first, then upload the filled AD to "
            "destination_folder_path as output_filename. An AD displaces nothing in "
            "the position folder, so do not archive the source for this conversion.")
    else:
        result["next"] = (
            "move every document displaced by this conversion into "
            "archive_folder_path, all under this same `stamp`, then upload the "
            "filled document to destination_folder_path as output_filename. "
            "displaced_filename is the archive name for the source itself; use "
            "`archive-name --stamp` for any other format of the same document.")
    return out(result, 0 if longest <= MAX_PATH else 2)


def cmd_verify(args):
    if not os.path.isfile(args.file):
        return out({"status": "ERROR", "reason": "file not found",
                    "path": args.file}, 2)
    data = open(args.file, "rb").read()
    valid, detail = validate(args.file)
    body = {
        "status": "OK" if valid else "ERROR",
        "file": os.path.basename(args.file),
        "bytes": len(data),
        "sha256": sha(data),
        "base64_chars": len(base64.b64encode(data)),
        "package_valid": valid,
        "package_detail": detail,
    }
    if args.expect_bytes is not None:
        body["expected_bytes"] = args.expect_bytes
        body["bytes_match"] = (args.expect_bytes == len(data))
        if not body["bytes_match"]:
            body["status"] = "MISMATCH"
            return out(body, 4)
    return out(body, 0 if valid else 2)


# ------------------------------------------------------------------- outline
# What the model needs in order to judge a template it has never seen: every
# paragraph, its style, whether it is highlighted, and whether it sits in a table.
#
# Nothing here guesses at MEANING. Python reports structure; the model decides
# what is an instruction to the filler, what is unwanted, and what is content.
# A regex that tried to recognise "delete this section" would be wrong in the
# next library, and wrong silently.

HEADING_STYLE = re.compile(r"^(heading\s*\d*|title|subtitle)$", re.I)


def set_heading_style(pattern):
    """Install what counts as a heading style in this template.

    The default matches Word's built-in Heading 1..9, Title and Subtitle. Real
    templates routinely mark their section banners with something else - one
    customer template styles every banner "Header" and uses a genuine heading
    style exactly once, on a sub-label. Guessing wrong moves a block boundary,
    so the pattern is an input rather than an assumption.
    """
    global HEADING_STYLE
    HEADING_STYLE = re.compile(pattern, re.I)
    return HEADING_STYLE


def runs_highlighted(p):
    """True if any run in this paragraph carries highlighting or shading."""
    for r in p.findall(qn("w:r")):
        rpr = r.find(qn("w:rPr"))
        if rpr is None:
            continue
        if (rpr.find(qn("w:highlight")) is not None
                or rpr.find(qn("w:shd")) is not None):
            return True
    return False


def is_heading(p):
    return bool(HEADING_STYLE.match(para_style(p) or ""))


def iter_outline_paragraphs(root):
    """Yield (index, paragraph, text) for every paragraph that has text.

    One enumeration, used by both `outline` and by filling a paragraph the caller
    addressed by number. If these ever walked the document differently, an index
    the caller read out of the outline would land somewhere else - so they share
    this rather than each having their own loop.
    """
    body = root.find(qn("w:body"))
    if body is None:
        return
    counter = [0]

    def walk(container, in_table):
        for el in list(container):
            if el.tag == qn("w:p"):
                text = para_text(el)
                if not text:
                    continue
                yield counter[0], el, text, in_table
                counter[0] += 1
            elif el.tag == qn("w:tbl"):
                for row in el.findall(qn("w:tr")):
                    for cell in row.findall(qn("w:tc")):
                        for item in walk(cell, True):
                            yield item

    for item in walk(body, False):
        yield item


def outline(root, limit=140):
    items = []
    for index, el, text, in_table in iter_outline_paragraphs(root):
        items.append({
            "index": index,
            "text": text[:limit],
            "truncated": len(text) > limit,
            "style": para_style(el),
            "heading": is_heading(el),
            "highlighted": runs_highlighted(el),
            "in_table": in_table,
            "has_placeholder": placeholder_match(text) is not None,
        })
    return items


# A map key of "@41" addresses outline row 41 directly.
#
# Field discovery names a blank from the label beside it, which needs that label
# to end in a colon. Plenty of templates do not write labels that way, and their
# blanks then have no name and cannot be filled at all - even though the caller
# can see perfectly well, in the outline, which heading the blank belongs to.
# Addressing the row by number closes that gap: discovery stays a convenience for
# the templates it handles, instead of being the limit of what can be filled.
INDEX_KEY = re.compile(r"^@(\d+)$")


# --------------------------------------------------------------------- prune
# Removal is always BY EXPLICIT TEXT, named by the caller. Nothing is removed by
# inference, and an ambiguous or missing match is reported rather than guessed at.
# Everything removed is returned in `removed`, with its text, so a deletion can be
# audited after the fact - which is the only thing that makes autonomous removal
# defensible on an HR document.

def norm_text(t):
    return re.sub(r"\s+", " ", t or "").strip().lower()


def ancestor_table(el, parents):
    while el is not None:
        el = parents.get(el)
        if el is not None and el.tag == qn("w:tbl"):
            return el
    return None


def cmd_prune(args):
    if getattr(args, "heading_style", None):
        set_heading_style(args.heading_style)
    # --remove is a path, not inline JSON. Check it the same way cmd_fill checks
    # --map: an unreadable path must come back as the error object every caller
    # parses, not as a traceback on stderr with nothing on stdout.
    for path in (args.docx, args.remove):
        if not os.path.isfile(path):
            return out({"status": "ERROR", "reason": "file not found",
                        "path": path}, 2)
    with open(args.remove, "r", encoding="utf-8") as fh:
        spec = json.load(fh)
    if isinstance(spec, dict):
        spec = spec.get("remove", [])
    if not isinstance(spec, list):
        return out({"status": "ERROR",
                    "reason": "remove file must be a list, or an object with a "
                              "'remove' list"}, 2)

    infos, raw = read_parts(args.docx)
    doc_i = next((i for i, inf in enumerate(infos)
                  if inf.filename == "word/document.xml"), None)
    if doc_i is None:
        return out({"status": "ERROR", "reason": "no word/document.xml"}, 2)
    root = parse(raw[doc_i])

    removed, not_found, ambiguous, unbounded = [], [], [], []

    for entry in spec:
        target = norm_text(entry.get("match"))
        scope = entry.get("scope", "block")
        why = entry.get("why", "")
        if not target:
            continue

        parents = parent_map(root)
        hits = [p for p in root.iter(qn("w:p"))
                if norm_text(para_text(p)) == target]
        matched_by = "exact"
        if not hits:
            # `outline` truncates long paragraphs, so the text the caller was shown
            # is often a prefix of the real one. Refusing that would mean an
            # instruction page quietly survives every run: the caller copies what it
            # saw, prune finds nothing, and the document ships with the page still
            # in it. A prefix that identifies exactly one paragraph is unambiguous,
            # so accept it - and say so, because a prefix match is a weaker claim
            # than an exact one.
            hits = [p for p in root.iter(qn("w:p"))
                    if target and norm_text(para_text(p)).startswith(target)]
            matched_by = "prefix"
        if not hits:
            not_found.append({"match": entry.get("match"), "why": why})
            continue
        if len(hits) > 1:
            ambiguous.append({"match": entry.get("match"), "matches": len(hits),
                              "matched_by": matched_by, "why": why})
            continue

        p = hits[0]
        if scope == "table":
            tbl = ancestor_table(p, parents)
            if tbl is None:
                not_found.append({"match": entry.get("match"),
                                  "why": "scope 'table' but the match is not in a table"})
                continue
            texts = [para_text(x) for x in tbl.iter(qn("w:p")) if para_text(x)]
            parents.get(tbl).remove(tbl)
            removed.append({"match": entry.get("match"), "scope": "table",
                            "paragraphs": len(texts), "why": why,
                            "first": texts[0][:120] if texts else "",
                            "last": texts[-1][:120] if texts else ""})
            continue

        parent = parents.get(p)
        if parent is None:
            not_found.append({"match": entry.get("match"),
                              "why": "matched paragraph has no parent"})
            continue
        siblings = list(parent)
        start = siblings.index(p)
        end = start + 1
        if scope == "block":
            # A block runs to the next boundary. The boundary is either a
            # paragraph the caller named with "until", or the next Word heading
            # style.
            #
            # If neither exists there is NO boundary, and a block removal would
            # run to the end of the document. Plenty of templates use bold body
            # text as headings and carry no heading styles at all, so this is the
            # common case, not the exotic one. Refuse it: deleting the rest of the
            # document because a boundary could not be found is the worst thing
            # this tool could do, and it would look like a successful removal.
            until = norm_text(entry.get("until")) if entry.get("until") else None
            bound = None
            stopped_before = None
            for j in range(start + 1, len(siblings)):
                el = siblings[j]
                if el.tag != qn("w:p"):
                    continue
                if until is not None:
                    if norm_text(para_text(el)) == until:
                        bound = j
                        break
                elif is_heading(el):
                    bound = j
                    break
            if bound is None:
                unbounded.append({
                    "match": entry.get("match"),
                    "why": why,
                    "reason": "scope 'block' found no boundary after this paragraph. "
                              "This document has no Word heading styles following it, "
                              "so the block has no end and nothing was removed. Name "
                              "the first paragraph to keep with \"until\", or remove "
                              "each paragraph with scope 'paragraph'.",
                })
                continue
            end = bound
            # Report the first paragraph with actual text, not the boundary
            # element itself. Templates are full of empty spacer paragraphs, and
            # these carry styles - the boundary here is an empty "Header" - so
            # naming the raw boundary reports an empty string and tells nobody
            # anything. The first surviving line is what makes a wrong boundary
            # obvious at a glance.
            stopped_before = ""
            for k in range(bound, len(siblings)):
                if siblings[k].tag == qn("w:p"):
                    t = para_text(siblings[k])
                    if t:
                        stopped_before = t[:120]
                        break

        texts = []
        for el in siblings[start:end]:
            if el.tag == qn("w:p"):
                t = para_text(el)
                if t:
                    texts.append(t)
            parent.remove(el)
        record = {"match": entry.get("match"), "scope": scope,
                  "matched_by": matched_by,
                  "paragraphs": len(texts), "why": why,
                  "first": texts[0][:120] if texts else "",
                  "last": texts[-1][:120] if texts else ""}
        if scope == "block":
            # The boundary is the whole risk in a block removal: pick the wrong
            # one and a heading you needed goes with the block, and the result
            # still reports OK. Naming it makes that checkable.
            record["stopped_before"] = stopped_before
        removed.append(record)

    if args.strip_all_highlight:
        n = 0
        for r in root.iter(qn("w:r")):
            rpr = r.find(qn("w:rPr"))
            if rpr is not None and (rpr.find(qn("w:highlight")) is not None
                                    or rpr.find(qn("w:shd")) is not None):
                strip_highlight(rpr)
                n += 1
        highlight_cleared = n
    else:
        highlight_cleared = 0

    out_path = args.out
    if os.path.abspath(out_path) == os.path.abspath(args.docx):
        return out({"status": "ERROR",
                    "reason": "--out must differ from --docx; removals are not "
                              "written over their own input",
                    "path": out_path}, 2)
    size = repack(infos, raw, {"word/document.xml": serialize(root)},
                  out_path, args.level)
    valid, detail = validate(out_path)

    return out({
        # A removal that matched nothing is a removal that did not happen. Returning
        # OK for it is how an instruction page ships to a customer inside their own
        # document with the run reported as a success.
        "status": ("OK" if valid and not ambiguous and not unbounded and not not_found
                   else "ERROR"),
        "file": os.path.basename(out_path),
        "upload_path": os.path.abspath(out_path),
        "bytes": size,
        "package_valid": valid,
        "package_detail": detail,
        "removed": removed,
        "removed_count": len(removed),
        "highlight_runs_cleared": highlight_cleared,
        "not_found": not_found,
        "ambiguous": ambiguous,
        "unbounded": unbounded,
        "note": "everything in `removed` must be repeated in the run report - an "
                "unlogged deletion is invisible to whoever reviews the document",
    }, 0 if valid and not ambiguous and not unbounded and not not_found else 2)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[1])
    sub = ap.add_subparsers(dest="cmd")

    def detection_flags(p):
        """Detection conventions, overridable when a template breaks with them."""
        p.add_argument("--placeholder", default=DEFAULT_PLACEHOLDER,
                       help="regex for what a blank looks like in this template")
        p.add_argument("--content-start", dest="content_start", default=None,
                       help="regex naming the first line of real content, when "
                            "alignment picks the wrong boundary")
        p.add_argument("--variant-marker", dest="variant_marker",
                       default=DEFAULT_VARIANT_MARKER,
                       help="regex marking a numbered alternative; group 1 is "
                            "the number")
        return p

    p = detection_flags(sub.add_parser("inspect"))
    p.add_argument("--docx", required=True)
    p.set_defaults(fn=cmd_inspect)

    p = detection_flags(sub.add_parser("fill"))
    p.add_argument("--docx", required=True)
    p.add_argument("--map", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(fn=cmd_fill)

    p = detection_flags(sub.add_parser("variants"))
    p.add_argument("--docx", required=True)
    p.set_defaults(fn=cmd_variants)

    p = detection_flags(sub.add_parser("prune"))
    p.add_argument("--docx", required=True)
    p.add_argument("--heading-style",
                   help="regex for the paragraph styles that end a block, when "
                        "this template does not use Word's built-in headings")
    p.add_argument("--remove", required=True,
                   help="path to a JSON file holding a list of "
                        "{match, scope, why}. scope is paragraph, block (to the "
                        "next heading) or table")
    p.add_argument("--out", required=True,
                   help="output path. Required: a tool that deletes should never "
                        "overwrite its own input by default")
    p.add_argument("--level", type=int, default=9)
    p.add_argument("--strip-all-highlight", dest="strip_all_highlight",
                   action="store_true",
                   help="also clear highlighting everywhere, not just on filled blanks")
    p.set_defaults(fn=cmd_prune)

    p = sub.add_parser("verify")
    p.add_argument("--file", required=True)
    p.add_argument("--expect-bytes", dest="expect_bytes", type=int, default=None)
    p.set_defaults(fn=cmd_verify)

    p = sub.add_parser("archive-name")
    p.add_argument("--file", required=True,
                   help="filename of the existing output being superseded")
    p.add_argument("--modified", default=None,
                   help="lastModifiedDateTime of that file, as SharePoint reports it")
    p.add_argument("--stamp", default=None,
                   help="use this stamp instead of deriving one, so every file "
                        "displaced by one conversion shares a single timestamp")
    p.set_defaults(fn=cmd_archive_name)

    p = sub.add_parser("report")
    p.add_argument("--run", required=True,
                   help="path to a JSON object holding what happened this run - "
                        "sourceFile, outputs[] with their byte counts, and notes")
    p.set_defaults(fn=cmd_report)

    p = sub.add_parser("sources")
    p.add_argument("--files", required=True,
                   help="path to a JSON listing of the files found in the position "
                        "folders - each needs a name, a folder path and a modified "
                        "time")
    p.set_defaults(fn=cmd_sources)

    p = sub.add_parser("destination")
    p.add_argument("--source", required=True,
                   help="SharePoint webUrl or path of the SOURCE document")
    p.add_argument("--allow-unresolved-source", dest="allow_unresolved_source",
                   action="store_true",
                   help="skip the resolved-path check (testing only; a sharing "
                        "link will produce the wrong destination)")
    p.add_argument("--output", choices=("pd", "ad"), default="pd",
                   help="pd: the filled document replaces the source in the "
                        "position folder. ad: it goes in the AD Documents "
                        "subfolder and displaces nothing")
    p.add_argument("--modified", default=None,
                   help="lastModifiedDateTime of the source, used for the stamp")
    p.add_argument("--stamp", default=None,
                   help="use this stamp instead of deriving one, so every file "
                        "displaced by one conversion shares a single timestamp")
    p.set_defaults(fn=cmd_destination)

    args = ap.parse_args(argv)
    if not getattr(args, "fn", None):
        ap.print_help(sys.stderr)
        return 2
    if getattr(args, "placeholder", None):
        set_placeholder(args.placeholder)
    if getattr(args, "variant_marker", None):
        set_variant_marker(args.variant_marker)
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
